export interface ILookupState {
    currentItemText?: string,
    isModelOpen?: boolean,
    //displayLoading?: boolean,
    lookupData?: ILookupData[]
    lookupColumns?: string[]
}

export interface ILookupData {
    id?: string
    text?: string
}

export interface IDynamicsColumn {
    schemaName: string,
    displayName: string,
    type: string
}

export interface IDataContext {
    entityToFetch: string,
    lookupAttributeOnPage: string,
    entityColumns: IDynamicsColumn[]
}

export interface IPageContext {
    webResourceURL: string
}