import * as React from 'react'
import { ShimmeredDetailsList, Fabric, StackItem, Link, PrimaryButton, Modal, IColumn, Text, SelectionMode, TextField } from 'office-ui-fabric-react/lib'
import { FontWeights, Stack } from '@fluentui/react'
import { mergeStyleSets, getTheme } from 'office-ui-fabric-react';
import { IDataContext, ILookupData, ILookupState, IPageContext } from './LookupState';

export default function CustomLookupCore(props: IPageContext) {

    const [lookupState, setLookupState] = React.useState<ILookupState>({});
    const [cachedLookupData, setLookupData] = React.useState<ILookupData[]>([]);
    const [isBusy, setIsBusy] = React.useState(true);

    const theme = getTheme();

    const contentStyles = mergeStyleSets({
        container: {
            display: 'flex',
            flexFlow: 'column nowrap',
            alignItems: 'stretch',
            width: '80%',
            height: '60%'
        },
        header: [

            theme.fonts.xLargePlus,
            {
                flex: '1 1 auto',
                borderTop: `4px solid ${theme.palette.themePrimary}`,
                color: theme.palette.neutralPrimary,
                display: 'flex',
                alignItems: 'center',
                fontWeight: FontWeights.semibold,
                padding: '12px 12px 14px 24px',
            },
        ],
        body: {
            flex: '4 4 auto',
            padding: '0 24px 24px 24px',
            overflowY: 'hidden',
            selectors: {
                p: { margin: '14px 0' },
                'p:first-child': { marginTop: 0 },
                'p:last-child': { marginBottom: 0 },
            },
        },
    });

    async function getWebResource(url: string) {
        const response = await fetch(url)
        return response.text();
    }

    React.useEffect(() => {
        getWebResource(props.webResourceURL).then(json => {
            const dataContext = JSON.parse(json) as IDataContext;

            const state: ILookupState =
            {
                currentItemText: Xrm.Page.data.entity.attributes.get(dataContext.lookupAttributeOnPage).getValue()[0].name,
                isModelOpen: false,
                lookupColumns: Array.from(dataContext.entityColumns, col => col.displayName)
            }

            setLookupState(state);


        }).catch(err => {
            Xrm.Utility.alertDialog(err, () => { });
        });




    }, [props])



    function timeout(ms: number) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }



    const onDialogOpen = () => {
        const state: ILookupState =
        {
            isModelOpen: true,
            lookupData: getData(),
            lookupColumns: ['Name', 'Age', 'Salary']
        }
        setIsBusy(true);
        setLookupData(state.lookupData || [])
        setLookupState(state);
        timeout(2000).then(() => {
            setIsBusy(false);
        })
    }

    function getListColumns() {
        var cols: IColumn[] = [];
        cols.push({
            key: "Selection",
            minWidth: 80,
            maxWidth: 180,
            name: "Select",
            isResizable: true,
            isCollapsible: true,
            data: 'string',
            onRender: (item: ILookupData) => {
                return (
                    <Link onClick={() => alert('you clicked on ' + item.id)}>Select</Link>
                )
            }
        });
        if (!lookupState.lookupColumns)
            return [];
        for (var i = 0; i < lookupState.lookupColumns!.length; i++) {
            cols.push({
                key: "Column" + i,
                minWidth: 80,
                maxWidth: 180,
                name: lookupState.lookupColumns![i],
                isResizable: true,
                isCollapsible: true,
                data: 'string',
                onRender: (item: ILookupData) => {
                    return (
                        <Text>{item.text}</Text>
                    )
                }
            })
        }

        return cols;
    }

    const getData = (): ILookupData[] => {
        var data: ILookupData[] = []
        for (var i = 0; i < 50; i++) {
            data.push({
                id: i.toString(),
                text: "text" + i
            });
        }

        return data;
    }


    const onTextFilter = (ev: any, tx?: string): void => {
        var filtered = tx ? cachedLookupData.filter(item => item.text!.indexOf(tx) > -1) : cachedLookupData
        setLookupState({
            isModelOpen: true,
            lookupColumns: lookupState.lookupColumns,
            lookupData: filtered
        })
    };

    const onDialogDismiss = () => {
        const state: ILookupState =
        {
            isModelOpen: false,
        }
        setLookupState(state);
    }

    return (
        <Fabric>
            <Stack horizontal>
                <StackItem>
                    <Link value="Affected Item">{lookupState.currentItemText}  </Link >
                </StackItem>

                <StackItem>
                    <PrimaryButton text="Open" onClick={onDialogOpen} />
                </StackItem>
            </Stack>

            <Modal
                isOpen={lookupState.isModelOpen}
                containerClassName={contentStyles.container}
                onDismiss={onDialogDismiss}>
                <div>
                    <table>
                        <tr>
                            {
                                lookupState.lookupColumns?.map((columnName) => {
                                    return (
                                        <td>
                                            <TextField disabled={isBusy} label={'Filter by ' + columnName} onChange={onTextFilter} />
                                        </td>
                                    )
                                })
                            }
                        </tr>
                    </table>
                </div>
                <div>
                    <ShimmeredDetailsList
                        selectionMode={SelectionMode.none}
                        compact
                        columns={getListColumns()}
                        items={lookupState.lookupData ? lookupState.lookupData : []}
                        enableShimmer={isBusy}
                    /></div>
            </Modal>
        </Fabric>
    )
}